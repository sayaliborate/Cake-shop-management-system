from django.apps import AppConfig


class CakeOrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cake_orders'
